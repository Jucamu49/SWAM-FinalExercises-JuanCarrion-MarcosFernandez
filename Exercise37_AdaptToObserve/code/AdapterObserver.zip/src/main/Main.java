package main;

import addaptedAcc.Account;
import app.Client;
import monitor.Monitor;
import app.Target;
import addaptedAcc.Adapter;

public class Main {

    public static void main(String[] args) {

    	Account account = new Account();
        Monitor monitor = new Monitor(account); 

        Target tarAccnt = new Adapter(account);
        Client client = new Client();

        client.run(tarAccnt);
    }
}