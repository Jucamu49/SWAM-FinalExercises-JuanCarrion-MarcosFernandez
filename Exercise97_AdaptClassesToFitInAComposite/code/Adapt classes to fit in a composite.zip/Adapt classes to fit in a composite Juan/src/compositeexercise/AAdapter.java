package compositeexercise;

public class AAdapter extends A implements Component {

	
	public AAdapter(boolean working) {
		super(working);
	}
	@Override
	public boolean test() {
		return opA();
	}

}
