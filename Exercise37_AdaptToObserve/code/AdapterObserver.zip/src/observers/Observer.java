package observers;

public interface Observer {
	void update(Object state, Subject sub);

}
