package compositeexercise;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CompositeAdapterTest {

    @Test
    void testAdapter() {
        AAdapter adapter = new AAdapter(true);

        assertTrue(adapter.test());
    }

    @Test
    void testCompositeSuccess() {
        Composite composite = new Composite();

        composite.addChild(new AAdapter(true));
        composite.addChild(new BAdapter(true));
        composite.addChild(new CAdapter(true));

        assertTrue(composite.test());
    }

    @Test
    void testCompositeFailure() {
        Composite composite = new Composite();

        composite.addChild(new AAdapter(true));
        composite.addChild(new BAdapter(false));
        composite.addChild(new CAdapter(true));

        assertFalse(composite.test());
    }

    @Test
    void testNestedComposite() {
        Composite root = new Composite();
        Composite subComposite = new Composite();

        subComposite.addChild(new AAdapter(true));
        subComposite.addChild(new BAdapter(true));

        root.addChild(subComposite);
        root.addChild(new CAdapter(true));

        assertTrue(root.test());
    }
}