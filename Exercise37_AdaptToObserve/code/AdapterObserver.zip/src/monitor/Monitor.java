package monitor;

import addaptedAcc.Account;
import addaptedAcc.Account.AccountState;
import observers.Observer;
import observers.Subject;

public class Monitor implements Observer {

    private AccountState state;

    public Monitor(Account account) {
        account.addObserver(this);
    }

    @Override
    public void update(Object arg, Subject sub) {
        if (arg instanceof AccountState) {
            this.state = (AccountState) arg;
        }	
    }
    
    public AccountState getState() { //For testing
        return state;
    }
}
