package app;

public interface Target {
	
	void pagar(double amount);
    String getBalance();
    
}