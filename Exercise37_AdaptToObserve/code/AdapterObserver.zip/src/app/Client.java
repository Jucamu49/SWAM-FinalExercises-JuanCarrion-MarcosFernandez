package app;

public class Client {

    public void run(Target account) {
        account.pagar(100);
        System.out.println(account.getBalance());
    }
}
	