package compositeexercise;
import java.util.ArrayList;
import java.util.List;

public class Composite implements Component {

    private List<Component> children = new ArrayList<>();

    @Override
    public void addChild(Component child) {
        children.add(child);
    }

    @Override
    public boolean test() {

        boolean result = true;

        for(Component child : children) {
            result = result && child.test();
        }

        return result;
    }
}