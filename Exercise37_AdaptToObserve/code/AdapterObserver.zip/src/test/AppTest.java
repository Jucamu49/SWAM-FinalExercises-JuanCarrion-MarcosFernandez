package test;

import addaptedAcc.Account;
import addaptedAcc.Account.AccountState;
import addaptedAcc.Adapter;
import app.Target;
import monitor.Monitor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;


public class AppTest {

    // Test 1: Adapter translates correctly
    @Test
    public void testAdapterTranslates() {
        Account account = new Account();
        Target adapter = new Adapter(account);

        adapter.pagar(100);

        assertEquals(AccountState.ACTIVE, account.getState());
        assertEquals(100.0, account.getBalance(), 0.001);

    }

    // Test 2: Monitor receives notification if the state changes, if not it shouldn't receive a notification (no setChanged())
    @Test
    public void testMonitorReceivesNotification() {
        Account account = new Account();
        Monitor monitor = new Monitor(account);

        // at the beginning, the state should be null
        assertNull(monitor.getState());

        account.setState(AccountState.ACTIVE);
        assertEquals(AccountState.ACTIVE, monitor.getState());

        boolean[] notified = {false};
        account.addObserver((arg, sub) -> notified[0] = true); //Add observer so that if update is called then notified[0] = true
        account.notifyObservers(); // changed is false (setChanged() wasn't called), it  shouldn't notify
        assertFalse(notified[0]);
    }

    // Test 3: self problem — We check if the reference that Account passes as this is the Adapter's one (it shouldn't be)
    @Test
    public void testSelfProblem() {
        Account account = new Account();
        Target adapter = new Adapter(account);

        boolean[] selfIsAccount = {false};
        account.addObserver((arg, sub) -> {
            selfIsAccount[0] = (sub == account);
        });

        adapter.pagar(100); // setState → notifyObservers(this)

        assertTrue(selfIsAccount[0]);
    }
}
