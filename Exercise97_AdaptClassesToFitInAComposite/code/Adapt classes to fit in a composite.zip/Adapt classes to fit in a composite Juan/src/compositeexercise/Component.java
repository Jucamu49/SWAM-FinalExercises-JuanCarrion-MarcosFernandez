package compositeexercise;

public interface Component {

    boolean test();

    default void addChild(Component child) {
        throw new UnsupportedOperationException();
    }
}