package compositeexercise;

public class CAdapter extends C implements Component {

	public CAdapter(boolean working) {
		super(working);
	}
	
	
	@Override
	public boolean test() {
		return opC();
	}

}
