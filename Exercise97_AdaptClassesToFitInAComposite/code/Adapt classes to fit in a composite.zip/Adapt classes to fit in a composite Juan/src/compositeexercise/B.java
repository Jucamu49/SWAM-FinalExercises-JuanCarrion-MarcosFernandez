package compositeexercise;

public class B {

private boolean working;
	
	public B(boolean working ){
		this.working=working;
	}
	
	public boolean opB() {
		System.out.print("Testing B ");
		return working;
	}
}
