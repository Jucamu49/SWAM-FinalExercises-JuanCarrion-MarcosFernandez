package observers;

import java.util.ArrayList;
import java.util.List;

public abstract class Subject {
	private List<Observer> observers = new ArrayList<>();
	private boolean changed = false;

	protected void setChanged() {
		changed = true;
	}

	public void addObserver(Observer o) {
		observers.add(o);
	}

	public void notifyObservers(Object arg) {
		if (!changed)
			return;

		for (Observer o : observers) {
			o.update(arg, this);
		}

		changed = false;
	}

	public void notifyObservers() {
		notifyObservers(null);
	}
}
