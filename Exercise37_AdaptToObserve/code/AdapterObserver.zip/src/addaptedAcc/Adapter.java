package addaptedAcc;

import app.Target;

public class Adapter implements Target {

    private Account account;
    
    public Adapter(Account account) {
        this.account = account;
    }

	@Override
	public void pagar(double amount) {
		if (amount > 0) {
	        account.deposit(amount);
	        account.setState(Account.AccountState.ACTIVE);
	    } else {
	        account.setState(Account.AccountState.BLOCKED);
	    }
	}

	@Override
	public String getBalance() {
		return account.getState().toString() + " " + account.getBalance();
	}
}
