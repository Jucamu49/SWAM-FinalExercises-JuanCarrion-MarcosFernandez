package compositeexercise;

public class A {

	private boolean working;
	
	public A(boolean working ){
		this.working=working;
	}
	
	public boolean opA() {
		System.out.print("Testing A ");
		return working;
	}
}
