package compositeexercise;

public abstract class Leaf implements Component {

	@Override
	public abstract boolean test();

}
