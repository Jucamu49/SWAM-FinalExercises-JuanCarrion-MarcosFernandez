package compositeexercise;

public class C {

private boolean working;
	
	public C(boolean working ){
		this.working=working;
	}
	
	public boolean opC() {
		System.out.print("Testing C ");
		return working;
	}
}
