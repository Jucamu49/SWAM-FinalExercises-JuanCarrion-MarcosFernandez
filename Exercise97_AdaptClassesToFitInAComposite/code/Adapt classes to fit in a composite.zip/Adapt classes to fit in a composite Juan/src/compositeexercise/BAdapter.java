package compositeexercise;

public class BAdapter extends B implements Component {

	public BAdapter(boolean working) {
		super(working);
	}
	
	@Override
	public boolean test() {
		return opB();
	}

}
