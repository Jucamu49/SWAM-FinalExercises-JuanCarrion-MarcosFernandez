package addaptedAcc;

import observers.Subject;

public class Account extends Subject {
	public enum AccountState {
	    ACTIVE,
	    BLOCKED,
	    CLOSED
	}
	private AccountState accountState;
    private double balance = 0;

	
	public void setState(AccountState state) {
        this.accountState = state;

        setChanged();
        notifyObservers(state);
    }

    public AccountState getState() {
        return accountState;
    }
    
    public void deposit(double amount) { 
        this.balance += amount;
    }

    public double getBalance() {
        return balance;
    }
}
